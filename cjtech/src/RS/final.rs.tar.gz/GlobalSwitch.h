#ifndef _GLOBALSWITCH_H
#define _GLOBALSWITCH_H

#define TEST_ON

#ifdef TEST_ON

#define LOG_ON 0x0001

#endif


#define SCHEDULING_ROTATE 0x0002

#endif
