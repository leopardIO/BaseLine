#include "DataFromatSwitch.h"

#include<iostream>
using namespace std;

namespace cjtech
{
    namespace RootServer
    {
        DataFromatSwitch::DataFromatSwitch()
        {

        }

        DataFromatSwitch::~DataFromatSwitch()
        {

        }

    }
}
